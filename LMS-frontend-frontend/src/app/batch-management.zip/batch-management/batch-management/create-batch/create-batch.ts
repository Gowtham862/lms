import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { liveclass } from '../../../core/services/liveclass/liveclass';
import { RouterLink } from '@angular/router';
import { Location } from '@angular/common';
import { CourseService } from '../../../course-management/course-service';
 
export interface Course {
  courseid: string;
  coursename: string;
   coursedesc: string;
 
}
export interface Createbatch{
 
  // course: Course | null;
    course: Course | null;
  batchNo: string | number;
  trainingMode: string;
  capacity: string | number;
  startDate: string;
  endDate: string;
  primarytrainerid: string | number;
  primarytrainername: string;
 
 
 
 
}
export interface CreateBatchPayload {
  courseid: string;
  batchno: string | number;
  trainingmode: string;
  studentcapacity: string | number;
  startdate: string;
  enddate: string;
}
@Component({
  selector: 'app-create-batch',
  imports: [FormsModule,CommonModule],
  templateUrl: './create-batch.html',
  styleUrl: './create-batch.scss',
})
export class CreateBatch {
  trainers: { trainerid: number, trainername: string }[] = [];
  courseSelected = false;
@Output() batchCreated = new EventEmitter<void>();
  @Output() close = new EventEmitter<void>();
  constructor(private service:liveclass,private location:Location, private courseService: CourseService, ){}
      course: Course[] = [];
     
  ngOnInit(): void {
         this.getLiveCourses();
         this.loadTrainers();
  }
 
batch: Createbatch = {
  course: null,  
  batchNo: '',
  trainingMode: '',
  capacity: '',
  startDate: '',
  endDate: '',
   primarytrainerid: '',
  primarytrainername: ''
   
 
};
goBack() {
    this.close.emit();
  }
 
    getLiveCourses() {
    this.service.publishedcourses().subscribe({
      next: (res: any) => {
          this.course = res.data.map((item: any) => ({
        courseid: item.courseid,
        coursename: item.coursename,
        coursedesc: item.coursedesc
      }));
        console.log(this.course)
     
      },
      error: (err) => {
        console.error('Error fetching courses', err);
      }
    });
  }
onTrainerChange(trainerid: any) {
  const selected = this.trainers.find(t => t.trainerid == trainerid);
  this.batch.primarytrainername = selected ? selected.trainername : '';
  console.log('Selected Trainer:', this.batch.primarytrainerid, this.batch.primarytrainername);
}
loadTrainers() {
    this.service.GetTrainers().subscribe({
      next: (res: any) => {
        console.log('Trainer API raw response:', res);
        this.trainers = (res.data || []).map((t: any) => ({
          trainerid: t.trainerid,
          trainername: t.trainername
        }));
         console.log('Mapped trainers in Edit:', this.trainers);
      },
      error: err => console.error('Error loading trainers', err)
    });
  }
 
createBatch() {
 
  if (!this.batch.course) return;
 
  /* Calculate total sessions */
  const totalSessions = this.modules.reduce(
    (sum, m) => sum + (m.sessions?.length || 0),
    0
  );
 
  const payload = {
    courseid: this.batch.course.courseid,
    coursename: this.batch.course.coursename,
      coursedesc: this.batch.course.coursedesc,
    batchno: this.batch.batchNo,
    trainingmode: this.batch.trainingMode,
    studentcapacity: this.batch.capacity,
    startdate: this.batch.startDate,
    enddate: this.batch.endDate,
       primarytrainerid: +this.batch.primarytrainerid,       // ✅ cast to number with +
   primarytrainer: this.batch.primarytrainername,
    status: 'Active',
    totalsessions: totalSessions,
 
    modules: this.modules.map(m => ({
      moduleNo: m.moduleNo,
      moduleName: m.moduleName,
      sessionDuration: m.sessionDuration,
      totalsession: m.totalsession,
     
      sessions: m.sessions || []
    }))
  };
 
  console.log('FINAL PAYLOAD →', payload);
 
  this.service.addbatchdata(payload).subscribe({
    next: () => {
      this.showSuccessModal = true;
      this.batchCreated.emit();
      // this.close.emit();
    },
    error: err => console.error(err)
  });
}
 
 
 
 
  courseOptions = [
    '1 Month',
    '3 Months',
    '6 Months',
    '12 Months'
  ];
 
  batchNos = [1, 2, 3, 4, 5];
 
  trainingModes = [
    'Online',
    'Offline'
  ];
 
  // for session
SessionModal = false;
 
courseName: string = '';   // Fix for courseName error
 
currentModule: any;
 
sessionList: any[] = [];
/* ================= MODULES (UI ONLY) ================= */
 
// modules: any[] = [];
 
// modules: any[] = [{
//     moduleName: '',
//     sessionDuration: '',
//     totalsession: 0
//   }];
 
modules: any[] = [];
 
 
openSessionModal(module: any) {
 
  if (!module) return;
 
  this.currentModule = module;
 
  const total = Number(module.totalsession);
 
  if (!total || total <= 0) {
    alert('Please enter total sessions');
    return;
  }
 
  /* If sessions already exist → load them */
  if (module.sessions?.length) {
    this.sessionList = module.sessions.map((s: any) => ({ ...s }));
  }
 
  /* Else create empty rows */
  else {
    this.sessionList = Array.from(
      { length: total },
      (_, i) => ({
        sessionNo: i + 1,
        startDate: '',
        startTime: '',
        endDate: '',
        endTime: ''
      })
    );
  }
 
  this.SessionModal = true;
}
 
showSuccessModal = false;
 
 closeSuccessModal() {
  this.showSuccessModal = false;
  this.batchCreated.emit();
  this.close.emit();  
}
 
 
 
closeSessionModal() {
  this.SessionModal = false;
}
 
saveSessionDetails() {
 
  if (!this.currentModule) return;
 
  /* Convert UI fields → API format */
  this.currentModule.sessions = this.sessionList.map((s: any) => ({
    sessionNo: s.sessionNo,
    starttime: s.startTime,
    endtime: s.endTime,
    sessionstartdate: s.startDate,
    sessionenddate: s.endDate
  }));
 
  console.log(
    'Saved sessions for module:',
    this.currentModule.moduleName,
    this.currentModule.sessions
  );
 
  this.SessionModal = false;
}
 
// onCourseChange(course: Course | null) {
 
//   this.courseSelected = !!course;
 
//   if (!course) {
//     this.modules = [];
//     return;
//   }
 
//   /* Create module rows dynamically */
//   this.modules = [
//     {
//       moduleName: 'Introduction',
//       sessionDuration: '1 Hour',
//       totalsession: 0   // start empty
//     },
//     {
//       moduleName: 'Advanced Topics',
//       sessionDuration: '2 Hours',
//       totalsession: 0
//     }
//   ];
 
//   this.courseName = course.coursename;
// }
 
 
onCourseChange(course: Course | null) {
 
  this.courseSelected = !!course;
 
  if (!course) {
    this.modules = [];
    return;
  }
 
  this.courseName = course.coursename;
 
  /* 🔥 CALL API BY ID */
  this.courseService.getCourseById(course.courseid)
    .subscribe({
      next: (res: any) => {
 
        console.log('Course By ID Response:', res);
 
        /* Map modules from API */
      this.modules = (res.data.modules || []).map((m: any, i: number) => ({
  moduleNo: i + 1,
  moduleName: m.moduleName,
  sessionDuration: m.sessionDuration,
  totalsession: m.totalsession || 0,
  sessions: m.sessions ? m.sessions.map((s: any) => ({
    sessionNo: s.sessionNo,
    starttime: s.starttime,
    endtime: s.endtime,
    sessionstartdate: s.sessionstartdate,
    sessionenddate: s.sessionenddate
  })) : []
}));
 
 
        console.log('Modules loaded:', this.modules);
      },
      error: err => {
        console.error('Failed to load modules', err);
      }
    });
}
 
 
// modules: any[] = [
//   {
//     moduleName: 'Introduction',
//     sessionDuration: '1 Hour',
//     totalsession: 2
//   }
// ];
 
   
}
 
 